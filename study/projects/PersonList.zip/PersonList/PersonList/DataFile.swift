//
//  DataFile.swift
//  PersonList
//
//  Created by 샤인 on 2017. 6. 26..
//  Copyright © 2017년 IosCamp. All rights reserved.
//

import Foundation

class DataFile {
    
    
    var friendList:[Person]?
    
    
    
}
